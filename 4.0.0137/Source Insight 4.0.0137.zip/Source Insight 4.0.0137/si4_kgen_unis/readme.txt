1. Install Source Insight 4.0
2. Copy file "msimg32.dll" from archive 
   to the folder with installed Source Insight
   ie: C:\Program Files (x86)\Source Insight 4.0
   This is the patch itself, helps to skip RSA signature checking,
   same time prevent access to internet.
3. Use keygen "si4_kgen_unis.exe" to generate the license file.
4. Run Source Insight
5. If it ask a license, select "Import a new license file.",
   and select created on step 3 *.lic file.
6. Done! Enjoy!